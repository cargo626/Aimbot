# Welcome to Krunker.io-Cheats!
This is a Krunker.io cheat loaded as a Chrome extension.

## :muscle: Features

* Aimbot
* Visible nicknames through the walls
* No recoil
* FPS Counter

## :hammer: Installation

1. Download [this repo as a ZIP file](https://github.com/PowerOfUniverse/Krunker.io-Cheats/archive/master.zip). 
2. Extract the ZIP file you just downloaded. 
3. Go to `chrome://extensions` in your browser. *Make sure you have Developer Mode activated.*
4. Click "Load Unpacked" and select the subfolder named `ChromeExtension` which is in the extracted (called `Krunker.io-Cheats-master.`)
5. Open [Krunker.io](http://krunker.io).
6. Have fun!

## :warning: Warning!
All actions you take at your own risk. The author is not responsible for the consequences of your actions.
